
from flask import Flask, request, redirect, url_for, render_template
from datetime import datetime

app = Flask(__name__)

temperatura = [
    {'vrijeme': 'Datum1', 'vrijednost': 23},
    {'vrijeme': 'Datum1', 'vrijednost': 23},
    {'vrijeme': 'Datum1', 'vrijednost': 23}
]

vlaga = []


@app.get('/')
def home_page():
    id = request.args.get('id', '1')

    if id == '1':
        naziv = 'Temperatura'
        podaci = temperatura
        jedinica = '°C'
        endpoint = 'temperatura'

    elif id == '2':
        naziv = 'Vlaga'
        podaci = vlaga
        jedinica = '%'
        endpoint = 'vlaga'

    else:
        naziv = 'Temperatura'
        podaci = temperatura
        jedinica = '°C'
        endpoint = 'temperatura'

    return render_template(
        'index.html',
        naziv=naziv,
        podaci=podaci,
        jedinica=jedinica,
        endpoint=endpoint
    ), 200


@app.get('/login')
def login_page():
    return render_template('login.html'), 200


@app.post('/login')
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    if username == 'PURS' and password == '1234':
        return redirect(url_for('home_page'))

    return redirect(url_for('login_page'))


@app.post('/temperatura')
def set_temperature():
    data = request.get_json(silent=True)

    if data is not None and data.get('temperatura') is not None:

        temperatura.append({
            'vrijeme': datetime.now().strftime('%d.%m.%Y %H:%M:%S'),
            'vrijednost': data.get('temperatura')
        })

        return 'Uspješno ste postavili temperaturu', 201

    return 'Niste napisali ispravan ključ', 404


@app.get('/temperatura')
def get_temperature():
    if len(temperatura) == 0:
        return {'poruka': 'Nema spremljenih temperatura'}, 404

    return {'temperatura': temperatura[-1]['vrijednost']}, 200


@app.delete('/temperatura')
def delete_temperature():
    id = request.args.get('id')

    if id is not None and id.isdigit() and int(id) < len(temperatura):
        temperatura.pop(int(id))

        return 'Uspješno ste obrisali temperaturu', 202

    return 'Upisali ste neispravan ključ', 404


@app.post('/vlaga')
def set_humidity():
    data = request.get_json(silent=True)

    if data is not None and data.get('vlaga') is not None:

        vlaga.append({
            'vrijeme': datetime.now().strftime('%d.%m.%Y %H:%M:%S'),
            'vrijednost': data.get('vlaga')
        })

        return 'Uspješno ste postavili vlagu', 201

    return 'Niste napisali ispravan ključ', 404


@app.get('/vlaga')
def get_humidity():
    if len(vlaga) == 0:
        return {'poruka': 'Nema spremljenih podataka o vlazi'}, 404

    return {'vlaga': vlaga[-1]['vrijednost']}, 200


@app.delete('/vlaga')
def delete_humidity():
    id = request.args.get('id')

    if id is not None and id.isdigit() and int(id) < len(vlaga):
        vlaga.pop(int(id))

        return 'Uspješno ste obrisali vlagu', 202

    return 'Upisali ste neispravan ključ', 404


@app.get('/logout')
def logout():
    return redirect(url_for('login_page'))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=True)
